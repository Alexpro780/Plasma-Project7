// Entry point for Plasma project
console.log('Welcome to Plasma!');